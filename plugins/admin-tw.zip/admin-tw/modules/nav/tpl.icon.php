<div class="dashicons-icon-user" title="user"></div>

<div class="dashicons-icon-user-female" title="user-female"></div>

<div class="dashicons-icon-users" title="users"></div>

<div class="dashicons-icon-user-follow" title="user-follow"></div>

<div class="dashicons-icon-user-following" title="user-following"></div>

<div class="dashicons-icon-user-unfollow" title="user-unfollow"></div>

<div class="dashicons-icon-trophy" title="trophy"></div>

<div class="dashicons-icon-speedometer" title="speedometer"></div>

<div class="dashicons-icon-social-youtube" title="social-youtube"></div>

<div class="dashicons-icon-social-twitter" title="social-twitter"></div>

<div class="dashicons-icon-social-tumblr" title="social-tumblr"></div>

<div class="dashicons-icon-social-facebook" title="social-facebook"></div>

<div class="dashicons-icon-social-dropbox" title="social-dropbox"></div>

<div class="dashicons-icon-social-dribbble" title="social-dribbble"></div>

<div class="dashicons-icon-shield" title="shield"></div>

<div class="dashicons-icon-screen-tablet" title="screen-tablet"></div>

<div class="dashicons-icon-screen-smartphone" title="screen-smartphone"></div>

<div class="dashicons-icon-screen-desktop" title="screen-desktop"></div>

<div class="dashicons-icon-plane" title="plane"></div>

<div class="dashicons-icon-notebook" title="notebook"></div>

<div class="dashicons-icon-moustache" title="moustache"></div>

<div class="dashicons-icon-mouse" title="mouse"></div>

<div class="dashicons-icon-magnet" title="magnet"></div>

<div class="dashicons-icon-magic-wand" title="magic-wand"></div>

<div class="dashicons-icon-hourglass" title="hourglass"></div>

<div class="dashicons-icon-graduation" title="graduation"></div>

<div class="dashicons-icon-ghost" title="ghost"></div>

<div class="dashicons-icon-game-controller" title="game-controller"></div>

<div class="dashicons-icon-fire" title="fire"></div>

<div class="dashicons-icon-eyeglasses" title="eyeglasses"></div>

<div class="dashicons-icon-envelope-open" title="envelope-open"></div>

<div class="dashicons-icon-envelope-letter" title="envelope-letter"></div>

<div class="dashicons-icon-energy" title="energy"></div>

<div class="dashicons-icon-emoticon-smile" title="emoticon-smile"></div>

<div class="dashicons-icon-disc" title="disc"></div>

<div class="dashicons-icon-cursor-move" title="cursor-move"></div>

<div class="dashicons-icon-crop" title="crop"></div>

<div class="dashicons-icon-credit-card" title="credit-card"></div>

<div class="dashicons-icon-chemistry" title="chemistry"></div>

<div class="dashicons-icon-bell" title="bell"></div>

<div class="dashicons-icon-badge" title="badge"></div>

<div class="dashicons-icon-anchor" title="anchor"></div>

<div class="dashicons-icon-action-redo" title="action-redo"></div>

<div class="dashicons-icon-action-undo" title="action-undo"></div>

<div class="dashicons-icon-bag" title="bag"></div>

<div class="dashicons-icon-basket" title="basket"></div>

<div class="dashicons-icon-basket-loaded" title="basket-loaded"></div>

<div class="dashicons-icon-book-open" title="book-open"></div>

<div class="dashicons-icon-briefcase" title="briefcase"></div>

<div class="dashicons-icon-bubbles" title="bubbles"></div>

<div class="dashicons-icon-calculator" title="calculator"></div>

<div class="dashicons-icon-call-end" title="call-end"></div>

<div class="dashicons-icon-call-in" title="call-in"></div>

<div class="dashicons-icon-call-out" title="call-out"></div>

<div class="dashicons-icon-compass" title="compass"></div>

<div class="dashicons-icon-cup" title="cup"></div>

<div class="dashicons-icon-diamond" title="diamond"></div>

<div class="dashicons-icon-direction" title="direction"></div>

<div class="dashicons-icon-directions" title="directions"></div>

<div class="dashicons-icon-docs" title="docs"></div>

<div class="dashicons-icon-drawer" title="drawer"></div>

<div class="dashicons-icon-drop" title="drop"></div>

<div class="dashicons-icon-earphones" title="earphones"></div>

<div class="dashicons-icon-earphones-alt" title="earphones-alt"></div>

<div class="dashicons-icon-feed" title="feed"></div>

<div class="dashicons-icon-film" title="film"></div>

<div class="dashicons-icon-folder-alt" title="folder-alt"></div>

<div class="dashicons-icon-frame" title="frame"></div>

<div class="dashicons-icon-globe" title="globe"></div>

<div class="dashicons-icon-globe-alt" title="globe-alt"></div>

<div class="dashicons-icon-handbag" title="handbag"></div>

<div class="dashicons-icon-layers" title="layers"></div>

<div class="dashicons-icon-map" title="map"></div>

<div class="dashicons-icon-picture" title="picture"></div>

<div class="dashicons-icon-pin" title="pin"></div>

<div class="dashicons-icon-playlist" title="playlist"></div>

<div class="dashicons-icon-present" title="present"></div>

<div class="dashicons-icon-printer" title="printer"></div>

<div class="dashicons-icon-puzzle" title="puzzle"></div>

<div class="dashicons-icon-speech" title="speech"></div>

<div class="dashicons-icon-vector" title="vector"></div>

<div class="dashicons-icon-wallet" title="wallet"></div>

<div class="dashicons-icon-arrow-down" title="arrow-down"></div>

<div class="dashicons-icon-arrow-left" title="arrow-left"></div>

<div class="dashicons-icon-arrow-right" title="arrow-right"></div>

<div class="dashicons-icon-arrow-up" title="arrow-up"></div>

<div class="dashicons-icon-bar-chart" title="bar-chart"></div>

<div class="dashicons-icon-bulb" title="bulb"></div>

<div class="dashicons-icon-calendar" title="calendar"></div>

<div class="dashicons-icon-control-end" title="control-end"></div>

<div class="dashicons-icon-control-forward" title="control-forward"></div>

<div class="dashicons-icon-control-pause" title="control-pause"></div>

<div class="dashicons-icon-control-play" title="control-play"></div>

<div class="dashicons-icon-control-rewind" title="control-rewind"></div>

<div class="dashicons-icon-control-start" title="control-start"></div>

<div class="dashicons-icon-cursor" title="cursor"></div>

<div class="dashicons-icon-dislike" title="dislike"></div>

<div class="dashicons-icon-equalizer" title="equalizer"></div>

<div class="dashicons-icon-graph" title="graph"></div>

<div class="dashicons-icon-grid" title="grid"></div>

<div class="dashicons-icon-home" title="home"></div>

<div class="dashicons-icon-like" title="like"></div>

<div class="dashicons-icon-list" title="list"></div>

<div class="dashicons-icon-login" title="login"></div>

<div class="dashicons-icon-logout" title="logout"></div>

<div class="dashicons-icon-loop" title="loop"></div>

<div class="dashicons-icon-microphone" title="microphone"></div>

<div class="dashicons-icon-music-tone" title="music-tone"></div>

<div class="dashicons-icon-music-tone-alt" title="music-tone-alt"></div>

<div class="dashicons-icon-note" title="note"></div>

<div class="dashicons-icon-pencil" title="pencil"></div>

<div class="dashicons-icon-pie-chart" title="pie-chart"></div>

<div class="dashicons-icon-question" title="question"></div>

<div class="dashicons-icon-rocket" title="rocket"></div>

<div class="dashicons-icon-share" title="share"></div>

<div class="dashicons-icon-share-alt" title="share-alt"></div>

<div class="dashicons-icon-shuffle" title="shuffle"></div>

<div class="dashicons-icon-size-actual" title="size-actual"></div>

<div class="dashicons-icon-size-fullscreen" title="size-fullscreen"></div>

<div class="dashicons-icon-support" title="support"></div>

<div class="dashicons-icon-tag" title="tag"></div>

<div class="dashicons-icon-trash" title="trash"></div>

<div class="dashicons-icon-umbrella" title="umbrella"></div>

<div class="dashicons-icon-wrench" title="wrench"></div>

<div class="dashicons-icon-ban" title="ban"></div>

<div class="dashicons-icon-bubble" title="bubble"></div>

<div class="dashicons-icon-camcorder" title="camcorder"></div>

<div class="dashicons-icon-camera" title="camera"></div>

<div class="dashicons-icon-check" title="check"></div>

<div class="dashicons-icon-clock" title="clock"></div>

<div class="dashicons-icon-close" title="close"></div>

<div class="dashicons-icon-cloud-download" title="cloud-download"></div>

<div class="dashicons-icon-cloud-upload" title="cloud-upload"></div>

<div class="dashicons-icon-doc" title="doc"></div>

<div class="dashicons-icon-envelope" title="envelope"></div>

<div class="dashicons-icon-eye" title="eye"></div>

<div class="dashicons-icon-flag" title="flag"></div>

<div class="dashicons-icon-folder" title="folder"></div>

<div class="dashicons-icon-heart" title="heart"></div>

<div class="dashicons-icon-info" title="info"></div>

<div class="dashicons-icon-key" title="key"></div>

<div class="dashicons-icon-link" title="link"></div>

<div class="dashicons-icon-lock" title="lock"></div>

<div class="dashicons-icon-lock-open" title="lock-open"></div>

<div class="dashicons-icon-magnifier" title="magnifier"></div>

<div class="dashicons-icon-magnifier-add" title="magnifier-add"></div>

<div class="dashicons-icon-magnifier-remove" title="magnifier-remove"></div>

<div class="dashicons-icon-paper-clip" title="paper-clip"></div>

<div class="dashicons-icon-paper-plane" title="paper-plane"></div>

<div class="dashicons-icon-plus" title="plus"></div>

<div class="dashicons-icon-pointer" title="pointer"></div>

<div class="dashicons-icon-power" title="power"></div>

<div class="dashicons-icon-refresh" title="refresh"></div>

<div class="dashicons-icon-reload" title="reload"></div>

<div class="dashicons-icon-settings" title="settings"></div>

<div class="dashicons-icon-star" title="star"></div>

<div class="dashicons-icon-symbol-female" title="symbol-female"></div>

<div class="dashicons-icon-symbol-male" title="symbol-male"></div>

<div class="dashicons-icon-target" title="target"></div>

<div class="dashicons-icon-volume-1" title="volume-1"></div>

<div class="dashicons-icon-volume-2" title="volume-2"></div>

<div class="dashicons-icon-volume-off" title="volume-off"></div>

